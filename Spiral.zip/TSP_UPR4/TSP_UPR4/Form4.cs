﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TSP_UPR4
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        //Отпечатва се квадратна матрица
        //Съдържа числата от 0 до N
        //Разположени като спирала
        //Започва от центъра на матрицата и се движи в обратна посока
        private void Form4_Load(object sender, EventArgs e)
        {



        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int N))
            {
                int[,] matrix = GenerateSpiralMatrix(N);


                label1.Text = GetMatrixAsString(matrix);
            }
            else
            {
                MessageBox.Show("Please enter a valid integer for N.");
            }
        }

        private int[,] GenerateSpiralMatrix(int N)
        {
            int[,] matrix = new int[N, N];
            int num = N * N;
            int row = N / 2;
            int col = N / 2;
            int dir = 0;

            for (int i = 1; i <= num; i++)
            {
                matrix[row, col] = i;

                if (dir == 0 && (col == N - 1 || matrix[row, col + 1] != 0))
                {
                    dir = 1; // Down
                }
                else if (dir == 1 && (row == N - 1 || matrix[row + 1, col] != 0))
                {
                    dir = 2; // Left
                }
                else if (dir == 2 && (col == 0 || matrix[row, col - 1] != 0))
                {
                    dir = 3; // Up
                }
                else if (dir == 3 && (row == 0 || matrix[row - 1, col] != 0))
                {
                    dir = 0; // Right
                }

                if (dir == 0) col++;
                else if (dir == 1) row++;
                else if (dir == 2) col--;
                else if (dir == 3) row--;
            }

            return matrix;
        }

        private string GetMatrixAsString(int[,] matrix)
        {
            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);
            string matrixString = "";

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrixString += matrix[i, j].ToString().PadLeft(4) + " ";
                }
                matrixString += Environment.NewLine;
            }

            return matrixString;
        }
    }
}
