using System.Security.Cryptography.X509Certificates;

namespace TSP_UPR4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public class WordHelper
        {
            public static string ReverseWord(string s)
            {
                char[] arr = s.ToCharArray();
                Array.Reverse(arr);
                return new string(arr);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s1, s2;
            s1 = s2 = textBox1.Text;
            s1 = WordHelper.ReverseWord(s1);
            if (s1 == s2)
            {
                MessageBox.Show("��������� �!");
            }
            else
            {
                MessageBox.Show("�� � ���������!");
            }
        }

        private void form2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 newForm = new Form2();
            newForm.ShowDialog();
        }

        private void form3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 newForm1 = new Form3();
            newForm1.ShowDialog();
        }

        private void form4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 newForm2 = new Form4();
            newForm2.ShowDialog();
        }
    }
}