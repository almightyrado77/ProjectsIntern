﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        Form2 frm = new Form2();
        SqlConnection myConnection;
        SqlCommand myCommand = default(SqlCommand);
        SqlDataAdapter adapt;


        private void DisplayData()
        {
            myConnection.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Car", myConnection);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            myConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                myConnection = new SqlConnection(frm.cs);
                myCommand = new SqlCommand("insert into Car(id_car, id_brand, id_model, id_client, price) " +
                "values(@id_car,@id_brand,@id_model,@id_client,@price)", myConnection);
                myConnection.Open();
                myCommand.Parameters.AddWithValue("@id_car", textBox1.Text);
                myCommand.Parameters.AddWithValue("@id_brand", textBox2.Text);
                myCommand.Parameters.AddWithValue("@id_model", textBox3.Text);
                myCommand.Parameters.AddWithValue("@id_client", textBox4.Text);
                myCommand.Parameters.AddWithValue("@price", textBox5.Text);
                myCommand.ExecuteNonQuery();
                myConnection.Close();
                MessageBox.Show("Insert successfully!");
                DisplayData();
                if (myConnection.State == ConnectionState.Open)
                {
                    myConnection.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                myConnection = new SqlConnection(frm.cs);
                myCommand = new SqlCommand("update Car set id_model=@id_model where id_car=@id_Car", myConnection);
                myConnection.Open();
                myCommand.Parameters.AddWithValue("@id_car", textBox1.Text);
                myCommand.Parameters.AddWithValue("@id_model", textBox2.Text);
                myCommand.ExecuteNonQuery();
                myConnection.Close();
                MessageBox.Show("Update successfully!");
                if (myConnection.State == ConnectionState.Open)
                {
                    myConnection.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                myConnection = new SqlConnection(frm.cs);
                myCommand = new SqlCommand("delete Car where id_car=@id_model", myConnection);
                myConnection.Open();
                myCommand.Parameters.AddWithValue("@id_car", textBox1.Text);
                myCommand.Parameters.AddWithValue("@id_model", textBox2.Text);
                myCommand.ExecuteNonQuery();
                myConnection.Close();
                MessageBox.Show("Delete successfully!");
                if (myConnection.State == ConnectionState.Open)
                {
                    myConnection.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            label1.Text = "Car";
            label2.Text = "id_car";
            label3.Text = "id_brand";
            label4.Text = "id_model";
            label5.Text = "id_client";
            label6.Text = "price";
            button1.Text = "Insert";
            button2.Text = "Update";
            button3.Text = "Delete";
        }
    }
}
