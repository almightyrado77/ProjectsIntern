﻿CREATE TABLE [dbo].[Client] (
    [Id_client]   INT          NOT NULL,
    [client_name] VARCHAR (50) NULL,
    [client_egn]  VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([Id_client] ASC)
);

