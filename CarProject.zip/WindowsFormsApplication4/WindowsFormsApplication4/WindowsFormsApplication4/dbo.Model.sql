﻿CREATE TABLE [dbo].[Model] (
    [Id_model]   INT          NOT NULL,
    [model_name] VARCHAR (50) NULL,
    [year]       DATE         NULL,
    PRIMARY KEY CLUSTERED ([Id_model] ASC)
);

