﻿CREATE TABLE [dbo].[Sales] (
    [Id_sale]      INT  NOT NULL,
    [num_sales]    INT  NULL,
    [date_of_sale] DATE NULL,
    [id_car] INT NULL, 
    PRIMARY KEY CLUSTERED ([Id_sale] ASC),
	CONSTRAINT [FK_Sales_Car]
	 FOREIGN KEY ([id_car]) 
	 REFERENCES [Car] ([id_car]) ON DELETE CASCADE
);

