﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        Form2 frm = new Form2();
        SqlConnection myConnection;
        SqlCommand myCommand;
        SqlDataAdapter adapt;
        private void Form3_Load(object sender, EventArgs e)
        {
            label1.Text = "Registration";
            label2.Text = "username";
            label3.Text = "password";
            button1.Text = "New record";
            button2.Text = "Reset";
            button3.Text = "Delete";
        }
        private void DisplayData()
        {
            myConnection.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select username from Registration where username='" + textBox1.Text + "'", myConnection);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            myConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                myConnection = new SqlConnection(frm.cs);
                myCommand = new SqlCommand("Insert into Registration values('" + textBox1.Text + "','" + textBox2.Text + "')", myConnection);
                myConnection.Open();
                myCommand.Parameters.AddWithValue("@username", textBox1.Text);
                myCommand.Parameters.AddWithValue("@password", textBox2.Text);
                myCommand.ExecuteNonQuery();
                myConnection.Close();
                MessageBox.Show("Insert successfully!");
                DisplayData();
                if (myConnection.State == ConnectionState.Open)
                {
                    myConnection.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                myConnection = new SqlConnection(frm.cs);
                myCommand = new SqlCommand("SELECT * FROM Registration WHERE username=@username", myConnection);
                SqlParameter uName = new SqlParameter("@username", SqlDbType.VarChar);
                uName.Value = textBox1.Text;
                myCommand.Parameters.Add(uName);
                myCommand.Connection.Open();
                SqlDataReader myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
                if (myReader.Read() == true)
                {
                    MessageBox.Show("Yes!!!");
                    myConnection.Close();
                    myConnection.Open();
                    myCommand.CommandType = CommandType.Text;
                    myCommand.CommandText = "Update Registration set password='" + textBox2.Text + "' where username='" + textBox1.Text + "'";
                    myCommand.ExecuteNonQuery();
                    myConnection.Close();
                    MessageBox.Show("Rеset password!");
                }
                else
                {
                    MessageBox.Show("There is no such user!", "Login user", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox1.Focus();
                }
                if (myConnection.State == ConnectionState.Open)
                {
                    myConnection.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                myConnection = new SqlConnection(frm.cs);
                myCommand = new SqlCommand("delete Registration where username=@username", myConnection);
                myConnection.Open();
                myCommand.Parameters.AddWithValue("@username", textBox1.Text);
                myCommand.ExecuteNonQuery();
                myConnection.Close();
                MessageBox.Show("Delete successfully!");
                DisplayData();
                if (myConnection.State == ConnectionState.Open)
                {
                    myConnection.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
