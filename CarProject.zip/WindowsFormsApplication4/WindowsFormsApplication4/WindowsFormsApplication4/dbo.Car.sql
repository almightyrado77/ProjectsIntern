﻿CREATE TABLE [dbo].[Car] (
    [Id_car]    INT        NOT NULL,
    [id_brand]  INT        NULL,
    [price]     FLOAT (53) NULL,
    [id_client] INT        NULL,
    PRIMARY KEY CLUSTERED ([Id_car] ASC),
	CONSTRAINT [FK_Car_Brand]
	 FOREIGN KEY ([id_brand]) 
	 REFERENCES [Brand] ([id_brand]) ON DELETE CASCADE,
	 CONSTRAINT [FK_Car_Client]
	 FOREIGN KEY ([id_client]) 
	 REFERENCES [Client] ([id_client]) ON DELETE CASCADE
);

