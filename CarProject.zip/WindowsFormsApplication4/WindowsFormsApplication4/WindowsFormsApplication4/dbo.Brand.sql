﻿CREATE TABLE [dbo].[Brand] (
    [Id_brand]   INT          NOT NULL,
    [brand_name] VARCHAR (50) NULL,
    [id_model] INT NULL, 
    PRIMARY KEY CLUSTERED ([Id_brand] ASC),
	 CONSTRAINT [FK_Brand_Model]
	 FOREIGN KEY ([id_model]) 
	 REFERENCES [Model] ([id_model]) ON DELETE CASCADE
);

