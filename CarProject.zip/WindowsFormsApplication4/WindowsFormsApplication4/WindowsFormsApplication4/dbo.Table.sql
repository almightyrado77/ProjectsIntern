﻿CREATE TABLE [dbo].[Registration]
(
	[username] NCHAR (30) NOT NULL,
	[password] NCHAR (256) NULL,
	CONSTRAINT [PK_Registration] PRIMARY KEY CLUSTERED ([username] ASC)
)
