module com.example.calendaroop {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;


    opens com.example.calendaroop to javafx.fxml;
    exports com.example.calendaroop;
}