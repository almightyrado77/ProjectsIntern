package bg.calendar;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class CalendarManager {
    private List<CalendarEvent> events = new ArrayList<>();
    private List<LocalDate> holidays = new ArrayList<>();
    private final FileManager fileManager = new FileManager();
    private List<CalendarEvent> calendarEvents = new ArrayList<>();
    public void loadFromFile(String filename) throws IOException {
        events = fileManager.loadEvents(filename);
        holidays = fileManager.loadHolidays(filename);
    }

    public void saveToFile(String filename) throws IOException {
        fileManager.saveToXml(filename, events, holidays);
    }
    public void clear() {
        calendarEvents.clear();
        holidays.clear();
    }

    public boolean bookEvent(CalendarEvent event) {
        for (CalendarEvent e : events) {
            if (e.getDate().equals(event.getDate()) &&
                    (event.getStartTime().isBefore(e.getEndTime()) &&
                            event.getEndTime().isAfter(e.getStartTime()))) {
                return false;
            }
        }
        events.add(event);
        return true;
    }

    public boolean unbookEvent(LocalDate date, LocalTime start, LocalTime end) {
        return events.removeIf(e ->
                e.getDate().equals(date) &&
                        e.getStartTime().equals(start) &&
                        e.getEndTime().equals(end));
    }

    public List<CalendarEvent> getAgenda(LocalDate date) {
        List<CalendarEvent> result = new ArrayList<>();
        for (CalendarEvent e : events) {
            if (e.getDate().equals(date)) {
                result.add(e);
            }
        }
        return result;
    }

    public boolean changeEvent(LocalDate date, LocalTime start, String field, String newValue) {
        for (CalendarEvent e : events) {
            if (e.getDate().equals(date) && e.getStartTime().equals(start)) {
                try {
                    switch (field.toLowerCase()) {
                        case "date":
                            e.setDate(LocalDate.parse(newValue));
                            break;
                        case "starttime":
                            e.setStartTime(LocalTime.parse(newValue));
                            break;
                        case "endtime":
                            e.setEndTime(LocalTime.parse(newValue));
                            break;
                        case "name":
                            e.setName(newValue);
                            break;
                        case "note":
                            e.setNote(newValue);
                            break;
                        default:
                            return false;
                    }
                    return true;
                } catch (Exception ex) {
                    return false;
                }
            }
        }
        return false;
    }

    public List<CalendarEvent> findEvents(String keyword) {
        List<CalendarEvent> result = new ArrayList<>();
        for (CalendarEvent e : events) {
            if (e.getName().toLowerCase().contains(keyword.toLowerCase()) ||
                    e.getNote().toLowerCase().contains(keyword.toLowerCase())) {
                result.add(e);
            }
        }
        return result;
    }

    public void addHoliday(LocalDate date) {
        if (!holidays.contains(date)) {
            holidays.add(date);
        }
    }

    public Map<DayOfWeek, Integer> getBusyDays(LocalDate from, LocalDate to) {
        Map<DayOfWeek, Integer> busyHours = new EnumMap<>(DayOfWeek.class);

        for (CalendarEvent event : calendarEvents) {
            LocalDate date = event.getDate();
            if ((date.isEqual(from) || date.isAfter(from)) && (date.isEqual(to) || date.isBefore(to))) {
                DayOfWeek day = date.getDayOfWeek();
                int duration = (int) java.time.Duration.between(event.getStartTime(), event.getEndTime()).toHours();
                busyHours.put(day, busyHours.getOrDefault(day, 0) + duration);
            }
        }

        return busyHours;
    }


    public List<LocalDate> getHolidays() {
        return holidays;
    }

    public Optional<CalendarEvent> findSlot(LocalDate fromDate, int durationHours) {
        LocalTime start = LocalTime.of(9, 0);
        LocalTime end = LocalTime.of(17, 0);
        for (int i = 0; i < 30; i++) {
            LocalDate date = fromDate.plusDays(i);
            boolean free = true;
            for (CalendarEvent e : events) {
                if (e.getDate().equals(date)) {
                    free = false;
                    break;
                }
            }
            if (free) {
                LocalTime slotEnd = start.plusHours(durationHours);
                return Optional.of(new CalendarEvent(date, start, slotEnd, "Free Slot", ""));
            }
        }
        return Optional.empty();
    }
}
