package bg.calendar;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class FileManager {

    public List<CalendarEvent> loadEvents(String filename) throws IOException {
        List<CalendarEvent> events = new ArrayList<>();
        try {
            File file = new File(filename);
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
            NodeList nodes = doc.getElementsByTagName("event");

            for (int i = 0; i < nodes.getLength(); i++) {
                Element element = (Element) nodes.item(i);

                LocalDate date = LocalDate.parse(getTagValue("date", element));
                LocalTime start = LocalTime.parse(getTagValue("start", element));
                LocalTime end = LocalTime.parse(getTagValue("end", element));
                String name = getTagValue("name", element);
                String note = getTagValue("note", element);

                events.add(new CalendarEvent(date, start, end, name, note));
            }
        } catch (Exception e) {
            throw new IOException("Failed to load XML file: " + e.getMessage());
        }
        return events;
    }

    public List<LocalDate> loadHolidays(String filename) throws IOException {
        List<LocalDate> holidays = new ArrayList<>();
        try {
            File file = new File(filename);
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
            NodeList nodes = doc.getElementsByTagName("holiday");

            for (int i = 0; i < nodes.getLength(); i++) {
                Element element = (Element) nodes.item(i);
                holidays.add(LocalDate.parse(element.getTextContent()));
            }
        } catch (Exception e) {
            throw new IOException("Failed to load holidays from XML: " + e.getMessage());
        }
        return holidays;
    }

    public void saveToXml(String filename, List<CalendarEvent> events, List<LocalDate> holidays) throws IOException {
        try {
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = docFactory.newDocumentBuilder();
            Document doc = builder.newDocument();

            Element root = doc.createElement("calendar");
            doc.appendChild(root);

            Element eventsEl = doc.createElement("events");
            root.appendChild(eventsEl);

            for (CalendarEvent e : events) {
                Element event = doc.createElement("event");

                appendChildWithText(doc, event, "date", e.getDate().toString());
                appendChildWithText(doc, event, "start", e.getStartTime().toString());
                appendChildWithText(doc, event, "end", e.getEndTime().toString());
                appendChildWithText(doc, event, "name", e.getName());
                appendChildWithText(doc, event, "note", e.getNote());

                eventsEl.appendChild(event);
            }

            Element holidaysEl = doc.createElement("holidays");
            root.appendChild(holidaysEl);
            for (LocalDate h : holidays) {
                appendChildWithText(doc, holidaysEl, "holiday", h.toString());
            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filename));
            transformer.transform(source, result);

        } catch (Exception e) {
            throw new IOException("Failed to save XML file: " + e.getMessage());
        }
    }

    private void appendChildWithText(Document doc, Element parent, String tag, String text) {
        Element child = doc.createElement(tag);
        child.appendChild(doc.createTextNode(text));
        parent.appendChild(child);
    }

    private String getTagValue(String tag, Element element) {
        NodeList nodes = element.getElementsByTagName(tag);
        if (nodes != null && nodes.getLength() > 0) {
            return nodes.item(0).getTextContent();
        }
        return "";
    }
}
