package bg.calendar;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class CalendarApp {

    private static final Scanner scanner = new Scanner(System.in);
    private static CalendarManager manager = new CalendarManager();
    private static String currentFilename = null;

    public static void main(String[] args) {
        System.out.println("Welcome to Personal Calendar!");
        boolean running = true;
        boolean fileLoaded = false;

        while (running) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();
            String[] parts = input.split("\\s+", 2);
            String command = parts[0].toLowerCase();

            if (!fileLoaded && !List.of("open", "exit", "help").contains(command)) {
                System.out.println("No file is open. Use 'open' to load a calendar file.");
                continue;
            }

            switch (command) {
                case "open":
                    openFile();
                    fileLoaded = true;
                    break;
                case "close":
                    closeFile();
                    fileLoaded = false;
                    break;
                case "save":
                    saveFile();
                    break;
                case "saveas":
                    saveFileAs();
                    break;
                case "book":
                    bookAppointment();
                    break;
                case "unbook":
                    unbookAppointment();
                    break;
                case "agenda":
                    showAgenda();
                    break;
                case "change":
                    changeAppointment();
                    break;
                case "find":
                    findAppointments();
                    break;
                case "holiday":
                    addHoliday();
                    break;
                case "busy":
                    showBusyDays();
                    break;
                case "free":
                    findFreeSlot();
                    break;
                case "help":
                    printHelp();
                    break;
                case "exit":
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Unknown command. Type 'help' for available commands.");
            }
        }
    }

    private static void openFile() {
        System.out.print("Enter filename to open: ");
        String filename = scanner.nextLine();
        try {
            manager.loadFromFile(filename);
            currentFilename = filename;
            System.out.println("Calendar loaded from " + filename);
        } catch (Exception e) {
            System.out.println("Error loading file: " + e.getMessage());
        }
    }

    private static void closeFile() {
        manager.clear();
        currentFilename = null;
        System.out.println("Successfully closed calendar.");
    }

    private static void saveFile() {
        if (currentFilename == null) {
            System.out.println("No file currently open. Use 'Save as' to specify a file.");
            return;
        }
        try {
            manager.saveToFile(currentFilename);
            System.out.println("Calendar saved to " + currentFilename);
        } catch (Exception e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }

    private static void saveFileAs() {
        System.out.print("Enter filename to save as: ");
        String filename = scanner.nextLine();
        try {
            manager.saveToFile(filename);
            currentFilename = filename;
            System.out.println("Calendar saved to " + filename);
        } catch (Exception e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }

    private static void bookAppointment() {
        try {
            System.out.print("Date (YYYY-MM-DD): ");
            LocalDate date = LocalDate.parse(scanner.nextLine().trim());

            System.out.print("Start time (HH:mm): ");
            LocalTime start = LocalTime.parse(scanner.nextLine().trim());

            System.out.print("End time (HH:mm): ");
            LocalTime end = LocalTime.parse(scanner.nextLine().trim());

            System.out.print("Name: ");
            String name = scanner.nextLine().trim();

            System.out.print("Note: ");
            String note = scanner.nextLine().trim();

            CalendarEvent event = new CalendarEvent(date, start, end, name, note);
            if (manager.bookEvent(event)) {
                System.out.println("Appointment booked.");
            } else {
                System.out.println("Time slot is busy. Appointment not booked.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input. Appointment not booked.");
        }
    }

    private static void unbookAppointment() {
        try {
            System.out.print("Date (YYYY-MM-DD): ");
            LocalDate date = LocalDate.parse(scanner.nextLine().trim());

            System.out.print("Start time (HH:mm): ");
            LocalTime start = LocalTime.parse(scanner.nextLine().trim());

            System.out.print("End time (HH:mm): ");
            LocalTime end = LocalTime.parse(scanner.nextLine().trim());

            if (manager.unbookEvent(date, start, end)) {
                System.out.println("Appointment canceled.");
            } else {
                System.out.println("No matching appointment found.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private static void showAgenda() {
        try {
            System.out.print("Date (YYYY-MM-DD): ");
            LocalDate date = LocalDate.parse(scanner.nextLine().trim());

            List<CalendarEvent> agenda = manager.getAgenda(date);
            if (agenda.isEmpty()) {
                System.out.println("No appointments for this date.");
            } else {
                for (CalendarEvent e : agenda) {
                    System.out.println(e);
                }
            }
        } catch (Exception e) {
            System.out.println("Invalid date.");
        }
    }

    private static void changeAppointment() {
        try {
            System.out.print("Date (YYYY-MM-DD): ");
            LocalDate date = LocalDate.parse(scanner.nextLine().trim());

            System.out.print("Start time (HH:mm): ");
            LocalTime start = LocalTime.parse(scanner.nextLine().trim());

            System.out.print("Field to change (date, starttime, endtime, name, note): ");
            String field = scanner.nextLine().trim();

            System.out.print("New value: ");
            String newValue = scanner.nextLine().trim();

            boolean changed = manager.changeEvent(date, start, field, newValue);
            if (changed) {
                System.out.println("Appointment updated.");
            } else {
                System.out.println("Failed to update appointment.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private static void findAppointments() {
        System.out.print("Search text: ");
        String search = scanner.nextLine().trim();
        List<CalendarEvent> results = manager.findEvents(search);
        if (results.isEmpty()) {
            System.out.println("No matching appointments found.");
        } else {
            for (CalendarEvent e : results) {
                System.out.println(e);
            }
        }
    }

    private static void addHoliday() {
        try {
            System.out.print("Holiday date (YYYY-MM-DD): ");
            LocalDate date = LocalDate.parse(scanner.nextLine().trim());
            manager.addHoliday(date);
            System.out.println("Holiday added.");
        } catch (Exception e) {
            System.out.println("Invalid date.");
        }
    }

    private static void showBusyDays() {
        try {
            System.out.print("Start date (YYYY-MM-DD): ");
            LocalDate from = LocalDate.parse(scanner.nextLine().trim());

            System.out.print("End date (YYYY-MM-DD): ");
            LocalDate to = LocalDate.parse(scanner.nextLine().trim());

            Map<java.time.DayOfWeek, Integer> busyDays = manager.getBusyDays(from, to);
            busyDays.entrySet().stream()
                    .sorted(Map.Entry.<java.time.DayOfWeek, Integer>comparingByValue().reversed())
                    .forEach(entry -> System.out.println(entry.getKey() + ": " + entry.getValue() + " hour(s)"));
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private static void findFreeSlot() {
        try {
            System.out.print("Start date (YYYY-MM-DD): ");
            LocalDate from = LocalDate.parse(scanner.nextLine().trim());

            System.out.print("Duration in hours: ");
            int hours = Integer.parseInt(scanner.nextLine().trim());

            Optional<CalendarEvent> slot = manager.findSlot(from, hours);
            if (slot.isPresent()) {
                CalendarEvent e = slot.get();
                System.out.println("Free slot: " + e.getDate() + " from " + e.getStartTime() + " to " + e.getEndTime());
            } else {
                System.out.println("No free slot found.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private static void printHelp() {
        System.out.println("Available commands:");
        System.out.println("  open     - Open calendar file");
        System.out.println("  close    - Close current calendar");
        System.out.println("  save     - Save current calendar");
        System.out.println("  saveas   - Save current calendar to a new file");
        System.out.println("  book     - Book a new appointment");
        System.out.println("  unbook   - Cancel an appointment");
        System.out.println("  agenda   - Show agenda for a specific date");
        System.out.println("  change   - Change an existing appointment");
        System.out.println("  find     - Search appointments by keyword");
        System.out.println("  holiday  - Add a holiday date");
        System.out.println("  busy     - Show busiest days of the week");
        System.out.println("  free     - Find the next free time slot");
        System.out.println("  help     - Show this help message");
        System.out.println("  exit     - Exit the application");
    }
}
