<footer class="bg-gradient-to-r from-zinc-800 via-zinc-900 to-stone-950 text-white py-2 text-center bottom-0 w-full">
      <div class="text-2xl font-bold ml-12">Yumly™</div>
</footer>