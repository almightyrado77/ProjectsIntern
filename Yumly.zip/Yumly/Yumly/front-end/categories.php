<?php
require 'database.php'; // връзка с базата данни

// Извличане на категориите от базата данни
$query = "SELECT id, name FROM categories";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Грешка при извличане на категориите: " . mysqli_error($conn));
}

$categories = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yumly | Categories</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<?php include 'header.php'; ?>
    <div class="max-w-4xl mx-auto my-10 bg-white p-6 rounded-lg shadow-lg">
        <h1 class="text-3xl font-bold text-gray-800 text-center mb-6">Categories</h1>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php foreach ($categories as $category): ?>
                <a href="recipes.php?category_id=<?php echo $category['id']; ?>" 
                   class="block bg-gray-200 p-6 text-center rounded-lg shadow-md hover:bg-blue-500 hover:text-white transition duration-300">
                    <h2 class="text-lg font-semibold"><?php echo htmlspecialchars($category['name']); ?></h2>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
