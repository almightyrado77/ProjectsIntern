<?php
require 'database.php';

// Проверка дали има подадено ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Извлича рецептата от базата данни
    $stmt = $pdo->prepare("SELECT * FROM recipes WHERE id = ?");
    $stmt->execute([$id]);
    $recipe = $stmt->fetch();

    // Ако рецептата не е намерена
    if (!$recipe) {
        echo '<p class="text-center text-red-500 font-semibold">Recipe not found!</p>';
        exit();
    }
} else {
    echo '<p class="text-center text-red-500 font-semibold">Invalid recipe ID!</p>';
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($recipe['name']); ?>Yumly | Recipe Details</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<?php if (!$is_logged_in): ?>
                            <li><a href="login.php" class="block p-2 text-base text-gray-900 rounded-lg hover:bg-gray-100">Login</a></li>
                            <li><a href="register.php" class="block p-2 text-base text-gray-900 rounded-lg hover:bg-gray-100">Register</a></li>
<?php endif; ?>
<?php include 'header.php'; ?>

    <div class="max-w-4xl mx-auto my-10 bg-white p-6 rounded-lg shadow-lg">
        <img src="<?php echo htmlspecialchars($recipe['image_path']); ?>" alt="<?php echo htmlspecialchars($recipe['name']); ?>" 
             class="w-full h-64 object-cover rounded-lg shadow-lg">
        <h1 class="text-3xl font-bold text-gray-800 mt-6"><?php echo htmlspecialchars($recipe['name']); ?></h1>

        <h2 class="text-xl font-semibold text-gray-700 mt-4">Ingredients:</h2>
        <p class="text-gray-600 mt-2"><?php echo nl2br(htmlspecialchars($recipe['ingredients'])); ?></p>

        <h2 class="text-xl font-semibold text-gray-700 mt-4">Preparation Instructions:</h2>
        <p class="text-gray-600 mt-2"><?php echo nl2br(htmlspecialchars($recipe['instructions'])); ?></p>

        <div class="mt-6">
            <a href="recipes.php" class="text-blue-500 font-semibold hover:underline">← Back to Recipes</a>
        </div>
    </div>
<?php include 'footer.php'; ?>
</body>
</html>
