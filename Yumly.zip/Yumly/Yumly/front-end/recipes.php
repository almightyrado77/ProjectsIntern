<?php
// Свързване с базата данни
require 'database.php';

// Обработка на формата за добавяне на рецепта
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $image = $_FILES['image'];

    // Проверка и качване на снимката
    if ($image['error'] == 0) {
        $imagePath = 'uploads/' . basename($image['name']);
        if (!is_dir('uploads')) {
            mkdir('uploads', 0777, true);
        }
        move_uploaded_file($image['tmp_name'], $imagePath);

        // Записване на рецептата в базата данни
        try {
            // Подготовка и изпълнение на SQL заявката за добавяне на нова рецепта
            $stmt = $conn->prepare("INSERT INTO recipes (name, image, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param('ss', $name, $imagePath);
            $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            echo "Error adding the recipe: " . $e->getMessage();
        }
    }
}

// Извличане на всички рецепти от базата данни
$recipes = [];
try {
    $result = $conn->query("SELECT id, name, image, created_at FROM recipes ORDER BY created_at DESC");
    while ($row = $result->fetch_assoc()) {
        $recipes[] = $row;
    }
} catch (mysqli_sql_exception $e) {
    echo "Грешка при извличане на рецепти: " . $e->getMessage();
}

// Проверка за категория
$categoryFilter = '';
if (isset($_GET['category_id'])) {
    $category_id = intval($_GET['category_id']);
    $stmt = $conn->prepare("SELECT * FROM recipes WHERE category_id = ?");
    $stmt->bind_param('i', $category_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $recipes = [];
    while ($row = $result->fetch_assoc()) {
        $recipes[] = $row;
    }

    // Извличане на категорията
    $stmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
    $stmt->bind_param('i', $category_id);
    $stmt->execute();
    $categoryName = $stmt->get_result()->fetch_column();
} else {
    $categoryName = "All Recipes";
}
?>

<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($categoryName); ?> | Yumly</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<?php include 'header.php'; ?>

    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-center mb-8 text-gray-800">Recipes</h1>

        <!-- Бутон за отваряне на модала -->
        <div class="text-center my-6">
            <button id="openModal" class="px-6 py-2 bg-blue-500 text-white font-semibold rounded hover:bg-blue-600 transition">
                Add own recipe
            </button>
        </div>

        <!-- Модал -->
        <div id="recipeModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden">
            <div class="bg-white w-full max-w-lg rounded-lg shadow-lg relative">
                <button id="closeModal" class="absolute top-2 right-2 text-gray-400 hover:text-gray-600">
                    ✖
                </button>
                <div class="p-6 border-b">
                    <h2 class="text-2xl font-bold text-gray-800 text-center">+ Add your own Recipe</h2>
                </div>
                <form action="recipes.php" method="POST" enctype="multipart/form-data" class="p-6 space-y-4">
                    <div>
                        <label for="name" class="block text-gray-700 font-semibold">Recipe's Name</label>
                        <input type="text" name="name" id="name" required
                               class="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
                    </div>
                    <div>
                        <label for="image" class="block text-gray-700 font-semibold">Recipe's Image</label>
                        <input type="file" name="image" id="image" accept="image/*" required
                               class="w-full p-2 border border-gray-300 rounded focus:outline-none">
                    </div>
                    <div>
                        <label for="ingredients" class="block text-gray-700 font-semibold">Ingredients</label>
                        <textarea name="ingredients" id="ingredients" rows="4" required
                                  class="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
                                  placeholder="List the ingredients, separated by commas."></textarea>
                    </div>
                    <div>
                        <label for="instructions" class="block text-gray-700 font-semibold">Preparation Instructions</label>
                        <textarea name="instructions" id="instructions" rows="6" required
                                  class="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
                                  placeholder="Describe how to prepare the recipe..."></textarea>
                    </div>
                    <button type="submit" name="submit"
                            class="w-full bg-blue-500 text-white font-semibold py-2 rounded hover:bg-blue-600 transition duration-300">
                        Publish
                    </button>
					
                </form>
            </div>
        </div>
<?php if (!$is_logged_in): ?>
                            <li><a href="login.php" class="block p-2 text-base text-gray-900 rounded-lg hover:bg-gray-100">Login</a></li>
                            <li><a href="register.php" class="block p-2 text-base text-gray-900 rounded-lg hover:bg-gray-100">Register</a></li>
<?php endif; ?>
        <div class="max-w-6xl mx-auto my-10 bg-white p-6 rounded-lg shadow-lg">
            <h1 class="text-3xl font-bold text-gray-800 text-center mb-6"><?php echo htmlspecialchars($categoryName); ?></h1>

            <div class="flex justify-end mb-4">
                <a href="categories.php" class="text-blue-500 hover:underline">← Back to Categories</a>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php foreach ($recipes as $recipe): ?>
                    <div class="w-full p-4">
                        <a href="recipe-details.php?id=<?php echo $recipe['id']; ?>" class="block group">
                            <img src="<?php echo htmlspecialchars($recipe['image']); ?>" 
                                 alt="<?php echo htmlspecialchars($recipe['name']); ?>" 
                                 class="w-full h-48 object-cover rounded-lg shadow-lg group-hover:scale-105 transition duration-300">
                            <h3 class="text-lg font-semibold text-gray-800 mt-2 group-hover:text-blue-500 transition">
                                <?php echo htmlspecialchars($recipe['name']); ?>
                            </h3>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
