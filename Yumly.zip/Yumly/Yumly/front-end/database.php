<?php
// Конфигурация за връзка с MySQL
$servername = "localhost";
$username = "root";
$password = "";
$database = "culinary_website";

// Създай връзка
$conn = mysqli_connect($servername, $username, $password);

// Проверка на връзката
if (!$conn) {
    die("Грешка при връзка с базата данни: " . mysqli_connect_error());
}

// Създай базата данни, ако не съществува
$sql_create_db = "CREATE DATABASE IF NOT EXISTS $database CHARACTER SET utf8 COLLATE utf8_general_ci";
if (!$conn->query($sql_create_db)) {
    die("Грешка при създаване на базата данни: " . $conn->error);
}

// Избери базата данни
mysqli_select_db($conn, $database);

// Създай таблицата 'users'
$sql_users = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=INNODB DEFAULT CHARSET=utf8";
if (!$conn->query($sql_users)) {
    die("Грешка при създаване на таблицата 'users': " . $conn->error);
}

// Създай таблицата 'recipes'
$sql_recipes = "CREATE TABLE IF NOT EXISTS recipes (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    preparation_time INT NOT NULL,
    cooking_time INT NOT NULL,
    user_id INT(11),
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8";
if (!$conn->query($sql_recipes)) {
    die("Грешка при създаване на таблицата 'recipes': " . $conn->error);
}

// Създай таблицата 'ingredients'
$sql_ingredients = "CREATE TABLE IF NOT EXISTS ingredients (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    quantity VARCHAR(50) NOT NULL,
    unit VARCHAR(50) NOT NULL,
    recipe_id INT(11),
    FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8";
if (!$conn->query($sql_ingredients)) {
    die("Грешка при създаване на таблицата 'ingredients': " . $conn->error);
}

// Създай таблицата 'categories'
$sql_categories = "CREATE TABLE IF NOT EXISTS categories (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8";
if (!$conn->query($sql_categories)) {
    die("Грешка при създаване на таблицата 'categories': " . $conn->error);
}

// Създай таблицата 'recipe_categories'
$sql_recipe_categories = "CREATE TABLE IF NOT EXISTS recipe_categories (
    recipe_id INT(11) NOT NULL,
    category_id INT(11) NOT NULL,
    FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    PRIMARY KEY (recipe_id, category_id)
) ENGINE=INNODB DEFAULT CHARSET=utf8";
if (!$conn->query($sql_recipe_categories)) {
    die("Грешка при създаване на таблицата 'recipe_categories': " . $conn->error);
}

// Създай таблицата 'comments'
$sql_comments = "CREATE TABLE IF NOT EXISTS comments (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    content TEXT NOT NULL,
    user_id INT(11) NOT NULL,
    recipe_id INT(11) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8";
if (!$conn->query($sql_comments)) {
    die("Грешка при създаване на таблицата 'comments': " . $conn->error);
}

// Създай таблицата 'ratings'
$sql_ratings = "CREATE TABLE IF NOT EXISTS ratings (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    rating INT(1) NOT NULL CHECK (rating >= 1 AND rating <= 5),
    user_id INT(11) NOT NULL,
    recipe_id INT(11) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8";
if (!$conn->query($sql_ratings)) {
    die("Грешка при създаване на таблицата 'ratings': " . $conn->error);
}
?>
