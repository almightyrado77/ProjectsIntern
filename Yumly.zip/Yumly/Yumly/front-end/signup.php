<!doctype html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
  <link href="../styles/main.css" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
</head>
<body class="bg-gray-100">
<?php include 'header.php'; ?>

<?php
// Връзка с базата данни
$servername = "localhost";
$username = "root";
$password = "";
$database = "culinary_website";

$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
    die("Грешка при връзка с базата данни: " . mysqli_connect_error());
}

// Обработка на данни при изпращане на формуляра
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);  // добавено е полето за имейл
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    if ($password === $confirm_password) {
        // Хеширане на паролата
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Вмъкване на потребителя в базата данни
        $sql = "INSERT INTO users (fullname, email, password) VALUES ('$fullname', '$email', '$hashed_password')";
        if (mysqli_query($conn, $sql)) {
            echo "Акаунтът е създаден успешно!";
        } else {
            echo "Грешка при създаване на акаунта: " . mysqli_error($conn);
        }
    } else {
        echo "Паролите не съвпадат.";
    }
}

mysqli_close($conn);
?>

<!--Hero Section-->
<div class="bg-grey-lighter min-h-screen flex flex-col">
    <div class="container max-w-sm mx-auto flex-1 flex flex-col items-center justify-center px-2">
        <div class="bg-white px-6 py-8 rounded shadow-md text-black w-full">
            <h1 class="mb-8 text-3xl text-center font-medium text-blue-600">Sign up</h1>
            <!-- Добавяне на форма за изпращане -->
            <form method="POST" action="">
                <input 
                    type="text"
                    class="block border border-grey-light w-full p-3 rounded mb-4 font-light"
                    id='signup-name'
                    name="fullname"
                    placeholder="Full Name" required />

                <input 
                    type="email"
                    class="block border border-grey-light w-full p-3 rounded mb-4 font-light"
                    id='signup-email'
                    name="email"
                    placeholder="Email Address" required />

                <input 
                    type="password"
                    class="block border border-grey-light w-full p-3 rounded mb-4 font-light"
                    id='signup-password'
                    name="password"
                    placeholder="Password" required />

                <input 
                    type="password"
                    class="block border border-grey-light w-full p-3 rounded mb-4 font-light"
                    id='signup-confirm-password'
                    name="confirm_password"
                    placeholder="Confirm Password" required />

                <button
                    type="submit"
                    class="w-full text-center py-3 rounded bg-blue-600 text-white hover:bg-blue-700 focus:outline-none my-1 font-regular"
                >Create Account</button>
            </form>

            <div class="text-center text-sm text-grey-dark mt-4 font-regular">
                By signing up, you agree to the 
                <a class="no-underline border-b border-grey-dark text-grey-dark" href="#">
                    Terms of Service
                </a> and 
                <a class="no-underline border-b border-grey-dark text-grey-dark" href="#">
                    Privacy Policy
                </a>
            </div>
        </div>

        <div class="text-grey-dark mt-6 font-regular">
            Already have an account? 
            <a class="no-underline border-b border-blue text-blue-600" href="login.html">
                Log in
            </a>.
        </div>
    </div>
</div>

<script type="text/javascript" src="../scripts/loginHandler.js" ></script>
<script type="text/javascript" src="../scripts/signupHandler.js"></script>
<?php include 'footer.php'; ?>
</body>
</html>
