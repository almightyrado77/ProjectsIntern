#include<iostream>
#include<fstream>
#include<string>
using namespace std;

//file is storing the data between 2 programs
ofstream file("output.txt");

//Excahnge Currency Class storing the data of sell rate, buy rate and etc.
struct Currency_Exchange
{
    friend class Exchange_offices;
    Currency_Exchange()
    {
        Max_Amount = 0;

        sell_rate = 0;
        buy_rate = 0;
    }

private:
    double sell_rate;       //Sell Rate
    double buy_rate;        //Buy Rate
    string ISO_currency;    //Currency Name
    int Max_Amount; // maximum amount to be exchanged
};

struct Exchange_offices
{

    Exchange_offices()
    {
        list_of_currencies = new Currency_Exchange[10];
        Registration_No = 0;
        Year_of_foundation = 0;
        Min_Amount = 0;
        counter = 0;
    }

    //This function adding a new office
    void Add_New_Office()
    {
        cout << "*********Enter first office information****************\n";
        cout << "Enter Name of Office: ";
        cin >> Name;
        file << Name << " ";
        cout << "Enter Reg. No: ";
        cin >> Registration_No;
        file << Registration_No << " ";
        cout << "Enter Year of Foundation: ";
        cin >> Year_of_foundation;
        file << Year_of_foundation << endl;
    }
    //This function adding a new Currency in the office
    void AddNewCurrency()
    {
        cout << "Enter ISO Currency: ";
        cin >> list_of_currencies[counter].ISO_currency;
        file << list_of_currencies[counter].ISO_currency << " ";
        cout << "Enter Buying Rate: ";
        cin >> list_of_currencies[counter].buy_rate;
        file << list_of_currencies[counter].buy_rate << " ";
        cout << "Enter Selling Rate: ";
        cin >> list_of_currencies[counter].sell_rate;
        file << list_of_currencies[counter].sell_rate << " ";
        cout << "Enter Maximum amount to be exchaged ";
        cin >> list_of_currencies[counter].Max_Amount;
        file << list_of_currencies[counter].Max_Amount << endl;
        if (counter == 0)
        {
            Min_Amount = list_of_currencies[counter].Max_Amount;
        }
        else
            if (Min_Amount > list_of_currencies[counter].Max_Amount)
            {
                Min_Amount = list_of_currencies[counter].Max_Amount;
            }
        counter++;
    }
    //Output of exchange offices with a minimum amount for exchange
    void Print_Offices();
    //Output of exchange offices with a Maximum amount for exchange
    void Print_OfficesM();
    //Output of exchange offices with a less than 6 Currencies
    void Print_Offices6();
    //Printing the Offices according to the given year interval
    void Print_Foundation(int, int);
    //Editting the Exchange Office and introducing a new Currency
    void Edit_exchange_office(Exchange_offices*, int, int);
    //Exchanging the Currencies
    void Exchange_courses(Exchange_offices*, int, int, double&);
    //Currencies List
    int Currencies_List()
    {
        int option;
        for (int i = 0; i < this->counter; i++)
        {
            cout << i + 1 << ": " << this->list_of_currencies[i].ISO_currency << endl;
        }
        cout << "In which currency you want to convert your money: ";
        cin >> option;
        return option - 1;
    }

private:
    int Min_Amount;     //Keeping track of minimum amount of Exchange office's Currency
    int Registration_No;//Registration Number
    int Year_of_foundation; //Year of Foundation
    string Name;            //Name of Office
    Currency_Exchange* list_of_currencies;  //List of Currencies in the Exchange office
    int counter;    //Number of Currennies
};
void Exchange_offices::Print_Offices()
{
    cout << "\n\nOffice name:";
    cout << Name;
    cout << "\nRegistration Number";
    cout << Registration_No;
    cout << "\nYear of Foundation: ";
    cout << Year_of_foundation;
    cout << "\nMinimum Amount for exchange: ";
    cout << Min_Amount;
    cout << "\n---------------------------------------\n";
    cout << endl << endl;
}
void Exchange_offices::Print_OfficesM()
{
    cout << "\n\nOffice name:";
    cout << Name;
    cout << "\nRegistration Number";
    cout << Registration_No;
    cout << "\nYear of Foundation: ";
    cout << Year_of_foundation;
    cout << "\nMinimum Amount for exchange: ";
    cout << Min_Amount;
    cout << "\nMaximum Amount for exchange: ";
    cout << list_of_currencies->Max_Amount;
    cout << "\n---------------------------------------\n";
    cout << endl << endl;
}
void Exchange_offices::Print_Offices6()
{
    if (counter < 6)
    {
        cout << "\n\nOffice name:";
        cout << Name;
        cout << "\nRegistration Number";
        cout << Registration_No;
        cout << "\nYear of Foundation: ";
        cout << Year_of_foundation;
        cout << "\nMinimum Amount for exchange: ";
        cout << Min_Amount;
        cout << "\nMaximum Amount for exchange: ";
        cout << list_of_currencies->Max_Amount;
        cout << "---------------------------------------\n";
        cout << endl << endl;
    }
}
void Exchange_offices::Print_Foundation(int I1, int I2)
{
    if (Year_of_foundation >= I1 && Year_of_foundation <= I2)
    {
        Print_Offices();
    }
}
void Exchange_offices::Edit_exchange_office(Exchange_offices* ptr, int office_id, int COUNT)
{
    if (this->Registration_No == office_id)
    {
        AddNewCurrency();
    }
    else
    {
        for (int i = 0; i < COUNT; i++)
        {
            if (ptr[i].Registration_No == office_id)
            {
                if (ptr[i].counter < 10)
                {
                    ptr[i].AddNewCurrency();
                }
                else
                {
                    cout << "Sorry the maximum number of currencies has alreadybeen entered\n";
                }
                return;
            }
        }
        cout << "Sorry the entered office number is matched\n";
    }
}
void Exchange_offices::Exchange_courses(Exchange_offices* ptr, int Id_office, int COUNT, double& currency)
{
    cout << "List of all currencies: ";
    int amount = 0;
    if (this->Registration_No == Id_office)
    {
        cout << this->list_of_currencies[0].ISO_currency << endl;
        cout << "How much amount you want to exchange: ";
        cin >> amount;
        file << amount << endl;

        int index = Currencies_List();

        if (amount < this->list_of_currencies[index].Max_Amount)
        {
            cout << "Converted amount from USD to " << this->list_of_currencies[index].ISO_currency;
            currency = currency * this->list_of_currencies[index].sell_rate;
        }
        else
            if (amount > this->list_of_currencies[index].Max_Amount)
            {
                cout << "Entered amount is greater than the max amount to be exchanged of the exchange office\n";
            }
    }
    else
        for (int i = 0; i < COUNT; i++)
        {
            if (ptr[i].Registration_No == Id_office)
            {
                int index = ptr[i].Currencies_List();
                cout << "How much amount you want to exchange: ";
                file << amount << endl;
                if (amount < ptr[i].list_of_currencies[index].Max_Amount)
                {

                    cout << "Converted amount from USD to " << ptr[i].list_of_currencies[index].ISO_currency;
                    currency = currency * ptr[i].list_of_currencies[index].sell_rate;
                }
                else
                    if (amount > ptr[i].list_of_currencies[index].Max_Amount)
                    {
                        cout << "Entered amount is greater than the max amount to be exchanged of the exchange office\n";
                    }
            }
        }
}

//Main Function
int main()
{
    cout << "---------------------------Exchange Currency Offices Managment System------------------------------\n\n";
    int number = 0;
    int option = -1;
    Exchange_offices E1;
    Exchange_offices* E2 = nullptr;
    while (option != 10)
    {
        cout << "\n-------------Menu---------------\n";
        cout << "1: Add a new exchange office with one exchange currency \n";
        cout << "2: Add a list of exchange offices\n";
        cout << "3: Display all exchange offices with minimum amount for exchange\n";
        cout << "4: Display all exchange offices with year of foundation in a given interval\n";
        cout << "5: Editing exchange offices\n";
        cout << "6: Enter the exchange office number, select a currency\n"
            << "from the list of exchange currencies and enter a value for exchange\n";
        cout << "7:  Listing the exchange offices with the year of establishment of the exchange office\n";
        cout << "8: Output of an exchange office with a maximum value for exchange"
            << "greater than the introduced one\n";
        cout << "9: Display of exchange offices with less than 6 currencies for exchange.\n";
        cout << "10: Exit\n";

        cout << "Enter your Choice: ";
        cin >> option;

        if (option == 1)
        {
            E1.Add_New_Office();
            E1.AddNewCurrency();
            cout << "\n---------Output of the Office-------------\n";
            E1.Print_Offices();
        }
        if (option == 2)
        {
            cout << "\n\n---------------------------------\n\n";
            cout << "Enter Number of offices: ";
            cin >> number;
            file << number << endl;
            if (number < 50 || number == 50 && number > 0)
            {
                E2 = new Exchange_offices[number];
                for (int i = 0; i < number; i++)
                {
                    E2[i].Add_New_Office();
                    E2[i].AddNewCurrency();
                }
            }
        }

        if (option == 3)
        {
            cout << "*******************OUTPUT OF OFFICES WITH MINIMUM AMOUNT FOR EXCHANGE*************\n";
            for (int i = 0; i < number; i++)
            {
                E2[i].Print_Offices();
            }
        }
        if (option == 4)
        {
            int year1, year2;
            cout << "\n\nPlease enter the year1 and year2 for interval printing from the list of Offices.\n";
            cout << "Year1: "; cin >> year1;
            cout << "Year2: "; cin >> year2;
            for (int i = 0; i < number; i++)
            {
                E2[i].Print_Foundation(year1, year2);
            }
        }
        if (option == 5)
        {
            int office_no;
            cout << "\n\nPlease Enter the Exchange office number(i.e, Registration number of exchange office): ";
            cin >> office_no;
            cout << "\n\n--------------------------------------------------\n";
            E1.Edit_exchange_office(E2, office_no, number);
            cout << "\n\n--------------------------------------------------\n";
        }

        if (option == 7)
        {
            int office_no2;
            cout << "\n\nPlease Enter the Exchange office number(i.e, Registration number of exchange office): ";
            double currency_to_be_exchanged = 10; ///USD
            cin >> office_no2;
            E1.Exchange_courses(E2, office_no2, number, currency_to_be_exchanged);
            cout << ": " << currency_to_be_exchanged << endl;
        }

        if (option == 7)
        {
            cout << "*******************OUTPUT OF OFFICES WITH Year of Establisment*************\n";
            for (int i = 0; i < number; i++)
            {
                E2[i].Print_Offices();
            }
        }

        if (option == 8)
        {
            for (int i = 0; i < number; i++)
            {
                E2[i].Print_OfficesM();
            }
        }

        if (option == 9)
        {
            for (int i = 0; i < number; i++)
            {
                E2[i].Print_Offices6();
            }
        }

        if (option == 10)
        {
            return 0;
        }

    }

    return 0;
}